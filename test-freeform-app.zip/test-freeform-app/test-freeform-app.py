from flask import * 
import requests
import os, sys, time

time.sleep(2)
# Flask constructor takes the name of
# current module (__name__) as argument.
app = Flask(__name__)

softversion = 1.1



# New updated stuff...


@app.route('/')
def home():
	return render_template('test-freeform-app.html', 
version=softversion)




# main driver function
if __name__ == '__main__':
	# run() method of Flask class runs the application
	# on the local development server.
	app.run(port=3501)

